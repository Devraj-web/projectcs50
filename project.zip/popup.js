// File: popup.js
document.getElementById("getQuote").addEventListener("click", function() {
    const quotes = [
        "Believe in yourself and all that you are.",
        "You are capable of amazing things.",
        "The best way to predict the future is to create it.",
        "Dream big, work hard, stay focused, and surround yourself with good people.",
        "Don’t stop until you’re proud."
    ];

    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    document.getElementById("quote").textContent = randomQuote;
});
