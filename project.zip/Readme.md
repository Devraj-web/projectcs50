YOUR PROJECT TITLE : Motivational quotes chrome extension using Javascript
 Video Demo: https://youtu.be/SUet6PdQlbI
 Description:The extension is made in purpose that whenever we are busy with our work or having a tough time we should see motivational quotes so that it would help us to focus better daily and so I have made this chrome extension.
